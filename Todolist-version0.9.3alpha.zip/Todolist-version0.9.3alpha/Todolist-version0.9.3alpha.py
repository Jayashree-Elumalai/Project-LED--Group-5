from tkinter import font
from tkinter import messagebox
import tkinter as tk
from tkinter import *
from tkinter import ttk
import sqlite3
from tkinter import messagebox
from tkcalendar import Calendar
from datetime import *
import time



#Register Page
def register_page():
    register_page = tk.Toplevel()
    register_page.title("Register Page")
    register_page.geometry("350x250")

    registerframe = tk.Frame(register_page)
    registerframe.pack()

    def check_everything():
        if len(entry.get()) != 0:
            email_confirm1 = "@"
            email_confirm2 = ".com"
            if email_confirm1 in entry2.get() and email_confirm2 in entry2.get():
                password = entry3.get()
                confirm_password = entry4.get()
                if len(password) != 0 or len(confirm_password) != 0:
                    if password == confirm_password:
                        register()
                    else:
                        messagebox.showerror("error!", "two password are not the same!")
                else:
                    messagebox.showerror("error!", "please fill up password and confirm password boxes!")
            else:
                tk.messagebox.showerror("invalid email", "this is not a valid email!", icon="error")
        else:
            tk.messagebox.showerror("ERROR", "Please type username!", icon="error")

    def show_password():

        if entry3.cget("show"):
            entry3.config(show="")
        else:
            entry3.config(show="*")

        if entry4.cget("show"):
            entry4.config(show="")
        else:
            entry4.config(show="*")

    def register():
        username = entry.get()
        password = entry3.get()
        email = entry2.get()

        # database
        conn = sqlite3.connect('todolist.db')
        create_table = '''
               CREATE TABLE IF NOT EXISTS todolist
               (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,username TEXT , password TEXT , email TEXT )
               '''
        conn.execute(create_table)
        cursor = conn.cursor()
        cursor.execute('''SELECT * FROM User_Information WHERE username=? OR email=?''', (username, email,))
        check_user_input = cursor.fetchone()
        if check_user_input is not None:
            tk.messagebox.showinfo("Used error", "This username or email already used!")
        else:
            insert_table = '''
                    INSERT INTO User_Information 
                    (username , password , email) 
                    VALUES 
                    (? , ? , ?);
                    '''

            insert_tuple = (username, password, email)
            cursor.execute(insert_table, insert_tuple)
            tk.messagebox.showinfo("REGISTERED", "register complete,thank you!")
            register_page.destroy()

        conn.commit()
        conn.close()

    word = tk.Label(registerframe, text="Username:", font=("arial", 12))
    word.grid(row=1, column=1, padx=10, pady=10)
    entry = tk.Entry(registerframe)
    entry.grid(row=1, column=2, padx=10, pady=10)

    word2 = tk.Label(registerframe, text="Email:", font=("arial", 12))
    word2.grid(row=2, column=1, padx=10, pady=10)
    entry2 = tk.Entry(registerframe)
    entry2.grid(row=2, column=2, padx=10, pady=10)

    word3 = tk.Label(registerframe, text="New password:", font=("arial", 12))
    word3.grid(row=3, column=1, padx=10, pady=10)
    entry3 = tk.Entry(registerframe, show="*")
    entry3.grid(row=3, column=2, padx=10, pady=10)

    word4 = tk.Label(registerframe, text="Confirm your password:", font=("arial", 12))
    word4.grid(row=4, column=1, padx=10, pady=10)
    entry4 = tk.Entry(registerframe, show="*")
    entry4.grid(row=4, column=2, padx=10, pady=10)

    cbutton = Checkbutton(registerframe, text="show password", font=("arial", 12), command=show_password)
    cbutton.grid(row=5, column=2, padx=10, pady=10)

    button = tk.Button(registerframe, text="Submit", command=check_everything, padx=30, pady=10)
    button.grid(row=5, column=1, )

#Main Page
n = 0
def main_page(USER_ID):
    root = tk.Tk()
    root.title('Todolist-version0.9alpha')
    root.geometry('620x200')

    # connect to the database
    conn = sqlite3.connect('todolist.db')
    cursor = conn.cursor()

    # create the Task_Information table if it doesn't exist
    cursor.execute(
        "CREATE TABLE IF NOT EXISTS Task_Information"
        "(Task_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,Task_name TEXT, "
        "Due_date TEXT,Task_state TEXT,Days_left TEXT,USER_ID INTEGER)")
    conn.commit()

    # calendar and getting the date
    def calendar():
        calendar_page = tk.Toplevel(root)
        cal = Calendar(calendar_page, selectmode='day', date_pattern='y-mm-dd')
        cal.pack()
        def get_date():
            due_date = cal.get_date()
            show_due_date.config(text=due_date)
            print(due_date)
            calendar_page.destroy()
        button = tk.Button(calendar_page, text="Choose this date", command=get_date)
        button.pack()

    # add task into treeview and database
    def add():
        due_date = show_due_date.cget("text")
        task_name = task_name_enter.get()
        if task_name == "":
            tk.messagebox.showerror("ERROR", "Please fill up the task name!", icon="error")
        else:
            # connect to the database and retrieve the maximum task ID
            cursor.execute("SELECT MAX(Task_ID) FROM Task_Information")
            result = cursor.fetchone()
            n = result[0] if result[0] else 0
            task_state = "processing"
            task_name_enter.delete(0, END)
            if due_date == "":
                due_date = "NO DUE DATE"
                tree.insert("", 'end', iid=n, values=(n, task_name, due_date, 'Processing'))
                cursor.execute("INSERT INTO Task_Information (Task_name,Due_date,Task_state,USER_ID)"
                               "VALUES ( ? , ? , ? , ? )", (task_name, due_date, task_state, USER_ID))
            else:
                tree.insert("", 'end', iid=n, values=(n, task_name, due_date, 'Processing'))
                cursor.execute("INSERT INTO Task_Information (Task_name,Due_date,Task_state,USER_ID)"
                               "VALUES ( ? , ? , ? , ? )", (task_name, due_date, task_state, USER_ID))
            update_days_left()

    # calculate days left and update it
    def update_days_left():
        cursor.execute("SELECT * FROM Task_Information")
        rows = cursor.fetchall()

        # update the days left for every row inside database
        for row in rows:
            old_time = row[2]
            new_time = datetime.strptime(old_time, "%Y-%m-%d")
            current_date = datetime.now().date()
            remaining_days = (new_time.date() - current_date).days
            cursor.execute("UPDATE Task_Information SET Days_left = ? WHERE Due_date = ? ", (remaining_days, row[2]))
            for row in tree.get_children():
                tree.delete(row)
            cursor.execute("SELECT * FROM Task_Information WHERE USER_ID = ?", (USER_ID,))
            rows = cursor.fetchall()
            for row in rows:
                tree.insert("", 'end', values=row)
            conn.commit()

    def delete():
        selected_items = tree.selection()
        for item in selected_items:
            item_name = tree.item(item)['values'][1]
            tree.delete(item)
            # delete data from the database
            cursor.execute("DELETE FROM Task_Information WHERE Task_name = ?", (item_name,))
            conn.commit()

    def finish_task():
        selected_item = tree.selection()
        if selected_item:
            item = tree.item(selected_item)
            values = item['values']

            Task_name_get = values[1]
            Due_date_get = values[2]
        tree.set(selected_item, 'Process', 'Finished')
        cursor.execute("UPDATE Task_Information SET Task_state = 'Finished' "
                       "WHERE Task_name = ? AND Due_date = ?",(Task_name_get,Due_date_get))
        conn.commit()

    def edit_selected_row():
        selected_item = tree.selection()
        if selected_item:
            item = tree.item(selected_item)
            values = item['values']

            show_due_date.config(text=values[2])
            task_name_enter.delete(0, tk.END)
            task_name_enter.insert(0, values[1])

    # entry_frame
    entry_frame = tk.LabelFrame(root, text="Entries")
    entry_frame.grid(row=0, column=0, columnspan=3, sticky="news")
    task_name = tk.Label(entry_frame, text="Task Name", font=("Cambria", 12))
    task_name.grid(row=0, column=0)
    task_name_enter = Entry(entry_frame)
    task_name_enter.grid(row=0, column=1)
    blank = tk.Label(entry_frame, text=" ", font=("Cambria", 12))
    blank.grid(row=0, column=2)
    due_date = tk.Label(entry_frame, text="Due Date:", font=("Cambria", 12))
    due_date.grid(row=0, column=3)
    show_due_date = tk.Label(entry_frame, text="", font=("Cambria", 12))
    show_due_date.grid(row=0, column=4)

    # task_frame
    Task_frame = tk.LabelFrame(root, text="Tasks")
    Task_frame.grid(row=2, column=0, columnspan=3, sticky="news")
    columns = ('Task_ID', 'Task_name', 'Due_date', 'Process', 'Days Left')
    tree = ttk.Treeview(Task_frame, columns=columns, show='headings')

    # add columns to the treeview
    for col in columns:
        tree.heading(col, text=col)

    # configure scrollbar for the treeview
    scrollbar = ttk.Scrollbar(Task_frame, orient="vertical", command=tree.yview)
    tree.configure(yscroll=scrollbar.set)
    scrollbar.pack(side="right", fill="y")

    update_days_left()
    while True:
        now = datetime.now()
        midnight = now.replace(hour=0, minute=0, second=0, microsecond=0)
        time_to_midnight = (midnight - now).total_seconds()

        # check if is midnight
        if time_to_midnight <= 0:
            update_days_left()
            break

        # wait until midnight
        time.sleep(time_to_midnight)

    # pack the treeview
    tree.pack()

    # function_frame
    Function_frame = tk.LabelFrame(root, text='Functions')
    Function_frame.grid(row=1, column=0, columnspan=3, sticky="news")
    add_task = tk.Button(Function_frame, text="Add Task", command=add)
    add_task.grid(row=1, column=0)
    delete_task = tk.Button(Function_frame, text="Delete Task", command=delete)
    delete_task.grid(row=1, column=1)
    finish_task = tk.Button(Function_frame, text="Finish Task", command=finish_task)
    finish_task.grid(row=1, column=2)
    edit_task = tk.Button(Function_frame, text="Edit Task", command=edit_selected_row)
    edit_task.grid(row=1, column=3)
    calendar_task = tk.Button(Function_frame, text="Choose Date", command=calendar)
    calendar_task.grid(row=1, column=4)

    root.mainloop()

#Login Page
#region
login = tk.Tk()
login.title("Login page")
login.geometry("400x400")
login.configure(bg="#D7D7D7")

def logining():
    # database
    conn = sqlite3.connect('todolist.db')
    create_table = '''
         CREATE TABLE IF NOT EXISTS User_Information
         (USER_ID INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,username TEXT , password TEXT , email TEXT )
         '''
    conn.execute(create_table)
    conn.commit()
    conn.close()

def loging():
    username = entry.get()
    email = entry2.get()
    password = entry3.get()

    conn = sqlite3.connect('todolist.db')
    cursor = conn.cursor()
    cursor.execute('''SELECT * FROM User_Information WHERE username=? AND password=? AND email =?''',
                   (username, password, email))
    row = cursor.fetchone()

    conn.close()
    email_confirm = "@"
    email_confirm2 = ".com"
    if email_confirm in email and email_confirm2 in email:
        if row is not None:
            USER_ID = row[0]
            tk.messagebox.showinfo("Login", "Login Successful !")
            main_page(USER_ID)
        else:
            tk.messagebox.showerror("Login", "Invalid username or password.", icon='error')
    else:
        tk.messagebox.showerror("invalid email", "this is not a valid email!", icon="error")


loginframe = tk.Frame(login, bg="#D7D7D7")
loginframe.pack()

welcome = tk.Label(loginframe, text="Login Page", font=("8514oem", 30), bg="#D7D7D7")
welcome.grid(row=1, column=2, pady=50, columnspan=2)

word = tk.Label(loginframe, text="Username", font=("Cambria", 12), bg="#D7D7D7")
word.grid(row=2, column=2)
entry = tk.Entry(loginframe, bd=2)
entry.grid(row=2, column=3, pady=10)

word2 = tk.Label(loginframe, text="Email", font=("Cambria", 12), bg="#D7D7D7")
word2.grid(row=3, column=2)
entry2 = tk.Entry(loginframe, width=20, bd=2)
entry2.grid(row=3, column=3, pady=10)

word3 = tk.Label(loginframe, text="Password", font=("Cambria", 12), bg="#D7D7D7")
word3.grid(row=4, column=2)
entry3 = tk.Entry(loginframe, width=20, bd=2)
entry3.grid(row=4, column=3, pady=10)

button_font = font.Font(family="Cambria", size=12, weight='bold')
button = tk.Button(loginframe, text="Login", font=button_font, bg="white", command=loging)
button.grid(row=5, column=2, columnspan=2, pady=10)

word3 = tk.Label(loginframe, text="Don't have account? Register here >>", font=("Times New Roman", 12), bg="#D7D7D7")
word3.grid(row=10, column=2)

button_font2 = font.Font(family="Cambria", size=12, weight='bold')
button2 = tk.Button(loginframe, text="Register", command=register_page, font=button_font2, bg="white")
button2.grid(row=10, column=3)

login.mainloop()
#endregion

